//--------------------------------------------------------------------------------------
// shape.h		shape Class - Virtual Base Class
//				�� Ŭ������ �߻�Ŭ����(abstract class)�̴�.
//
// 2017. 12. 3  KimWooBin
//--------------------------------------------------------------------------------------
#ifndef _shape
#define _shape

class Shape
{
public:
	Shape() {};
	virtual ~Shape() {};

	virtual void draw() const = 0;
};
#endif // !_shape

