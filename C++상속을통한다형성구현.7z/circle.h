//----------------------------------------------------------------------------------------------------------
// circle.h
// 
// 2017. 12. 3
//----------------------------------------------------------------------------------------------------------
#include <iostream>
#include "point.h"
#include "shape.h"
#include <string>

class Circle : public Shape
{
	Point center;
	double rad;
	int type;

public:
	Circle();
	Circle(const Point&, double) ;
	Circle(const Circle&);
	

	virtual void save(std::string&);


	//Circle(const Circle&) = default;
	~Circle();

	virtual void draw() const override;
};