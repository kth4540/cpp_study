//----------------------------------------------------------------------------------------------------------
// triangle.h
//
// 2017. 12. 3
//----------------------------------------------------------------------------------------------------------

#include "point.h"
#include "shape.h"
#include <string>

class Triangle : public Shape
{
	Point p1, p2, p3;
	int type;

public:
	Triangle();
	Triangle(const Point&, const Point&, const Point&);
	Triangle(const Triangle&);
	
	virtual void save(std::string&);


	~Triangle();
	int getType() {
		return type;
	}

	virtual void draw() const override;
};
