//------------------------------------------------------------------------------------------------------
// rectangle.h
//
// 2017. 12. 3
//------------------------------------------------------------------------------------------------------

#include "point.h"
#include "shape.h"
#include <string>

class Rectangle : public Shape
{
	Point p1, p2;
	int type;
public:
	Rectangle();
	Rectangle(const Point&, const Point&);
	Rectangle(const Rectangle&);

	virtual void save(std::string&);


	~Rectangle();

	virtual void draw() const override;
};