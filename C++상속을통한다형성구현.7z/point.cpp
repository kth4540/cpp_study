#include "point.h"

Point::Point() : x(0.0), y(0.0) { };

Point::Point(double a, double b) : x(a), y(b) {};