//---------------------------------------------------------------------------------------------
// rectangle.cpp
//
// 2017. 12. 3
//---------------------------------------------------------------------------------------------

#include <iostream>
#include "rectangle.h"
#include "shapeManager.h"
#include <fstream>

Rectangle::Rectangle() : p1(), p2() {};

Rectangle::Rectangle(const Point& a, const Point& b) : p1(a), p2(b), type(1) {};

Rectangle::Rectangle(const Rectangle& other) : p1(other.p1), p2(other.p2) {};

void Rectangle::save(std::string& name) {
	std::fstream out(name, std::ios::app);
	out << "2" << " " << p1.x << " " << p1.y << " " << p2.x << " " <<  p2.y <<std::endl;
}

Rectangle::~Rectangle() {}

void Rectangle::draw() const
{
	std::cout << "�簢�� - (" << p1.x << "," << p1.y << "),(" << p2.x << "," << p2.y << ")" << std::endl;

};