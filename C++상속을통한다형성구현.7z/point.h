//-----------------------------------------------------------------------------------------
//
// 2017. 12. 3 by KimWooBin
//-----------------------------------------------------------------------------------------
#ifndef _Point
#define _Point

struct Point
{
	double x, y;

	Point();
	Point(double x, double y);
	Point(const Point&) = default;
};
#endif
