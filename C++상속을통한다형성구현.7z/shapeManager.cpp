//-----------------------------------------------------------------------------------------------------------
// shapeManager.cpp
//
// 2017. 12. 3
//-----------------------------------------------------------------------------------------------------------

#include <iostream>
#include "point.h"
#include "triangle.h"
#include "circle.h"
#include "rectangle.h"
#include "shapeManager.h"
#include <fstream>
#include <string>

using namespace std;

//------------------------------------
ShapeManager::ShapeManager(int n)
//------------------------------------
{
	nShape = 0;
	capacity = n;
	shapes = new Shape*[capacity];
}

//-------------------------------------
ShapeManager::~ShapeManager()
//-------------------------------------
{

	for (int i = 0; i < nShape; ++i)
		delete shapes[i];
	delete[] shapes;

}

//-------------------------------------
void ShapeManager::insert(Shape* a)
//-------------------------------------
{
	shapes[nShape] = a;
	nShape++;
}

void ShapeManager::save() {
	system("cls");
	cout << "������ ���ϸ��� �Է��� �ּ���: ";
	string fileName;
	cin >> fileName;
	
	fstream out(fileName,ios::app);
	
	out << nShape << endl;

	for (int i = 0; i < nShape; ++i) {
		if (dynamic_cast<Triangle*>(shapes[i]) != nullptr)
			dynamic_cast<Triangle*>(shapes[i])->save(fileName);
		else if (dynamic_cast<Rectangle*>(shapes[i]) != nullptr)
			dynamic_cast<Rectangle*>(shapes[i])->save(fileName);
		else if (dynamic_cast<Circle*>(shapes[i]) != nullptr)
			dynamic_cast<Circle*>(shapes[i])->save(fileName);
	}

	system("cls");
	cout << "����Ǿ����ϴ�!" << endl;
}

//-------------------------------------
void ShapeManager::Delete()
//-------------------------------------
{
	system("cls");
	cout << "==============================================================================" << endl;
	cout << "1. ��ȣ�� ����" << endl;
	cout << "2. Ŭ���� ����" << endl;
	int select;
	cout << "==============================================================================" << endl;
	cout << "������ �ּ��� (1~2): ";
	cin >> select;

	if (select == 1)
	{
		system("cls");
		cout << "�p��° ������ �����ұ��? (0 ~ " << nShape - 1 << "): ";
		int deleteK;
		cin >> deleteK;

		delete shapes[deleteK];

		for (int i = deleteK; i < nShape; ++i)
			shapes[i] = shapes[i + 1];
		nShape--;

		system("cls");
		cout << "=============================================================================" << endl;
		cout << deleteK << "��° ������ ���� �Ͽ����ϴ�!!!!!" << endl;
		cout << "=============================================================================" << endl << endl;
	}
	else if (select == 2)
	{
		system("cls");
		cout << "=============================================================================" << endl;
		cout << "1. �ﰢ��" << endl;
		cout << "2. �簢��" << endl;
		cout << "3. ��" << endl;
		cout << "=============================================================================" << endl;
		cout << "� ������ �����ұ��? (1~3): ";
		int deleteC;
		cin >> deleteC;
		int count = 0;

		switch (deleteC)
		{
		case 1:
			for (int i = 0; i < nShape; ++i) {
				if (dynamic_cast<Triangle*>(shapes[i]) != nullptr) {
					delete shapes[i];
					++count;
				}
				else
					shapes[i - count] = shapes[i];
			}
			nShape -= count;
			count = 0;
			break;

		case 2:
			for (int i = 0; i < nShape; ++i) {
				if (dynamic_cast<Rectangle*>(shapes[i]) != nullptr) {
					delete shapes[i];
					++count;
				}
				else
					shapes[i - count] = shapes[i];
			}
			nShape -= count;
			count = 0;
			break;

		case 3:
			for (int i = 0; i < nShape; ++i) {
				if (dynamic_cast<Circle*>(shapes[i]) != nullptr) {
					delete shapes[i];
					++count;
				}
				else
					shapes[i - count] = shapes[i];
			}
			nShape -= count;
			count = 0;
			break;
		}

		for (int i = 1; i < nShape; ++i)
			if (shapes[i-1] == 0)
				shapes[i-1] = shapes[i];
	}
}


void ShapeManager::recover()
{
	system("cls");
	int n, x1, x2, x3, y1, y2, y3;
	double rad;
	string fileName;
	int cnt;

	cout << "������ ���� �̸��� �Է��� �ּ���: ";
	cin >> fileName;
	ifstream in(fileName);
	in >> cnt;

	for (int i = 0; i < cnt; ++i) {
		in >> n;
		if (n == 1) {
			in >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
			insert(new Triangle(Point(x1, y1), Point(x2, y2), Point(x3, y3)));
		}
		else if (n == 2) {
			in >> x1 >> y1 >> x2 >> y2;
			insert(new Rectangle(Point(x1, y1), Point(x2, y2)));
		}
		else if (n == 3) {
			in >> x1 >> y1 >> rad;
			insert(new Circle(Point(x1, y1), rad));
		}
	}
	system("cls");
	cout << "������ �Ϸ�Ǿ����ϴ�!" << endl << endl;
}

//-------------------------------------
void ShapeManager::draw()
//-------------------------------------
{
	cout << "=============================================================================" << endl;
	cout << "�����ϴ� ��� ������ �׸��ϴ�." << endl;
	cout << "�ִ� " << capacity << "���� ������ ���� �� �ֽ��ϴ�." << endl;
	cout << "��� " << nShape << "���� ������ �ֽ��ϴ�." << endl;
	cout << "=============================================================================" << endl << endl;

	for (int i = 0; i < nShape; ++i) {
		cout << "[" << i << "]";
		shapes[i]->draw();
	}
	cout << endl;

	cout << "=============================================================================" << endl;
	cout << "�׸��⸦ ��Ĩ�ϴ�." << endl;
	cout << "=============================================================================" << endl;
};
