//-------------------------------------------------------------------------------------------------------
// circle.cpp
//
// 2017. 12. 3
//-------------------------------------------------------------------------------------------------------

#include <iostream>
#include "circle.h"
#include "shape.h"
#include <fstream>
#include "shapeManager.h"

Circle::Circle() : center(), rad(0){}

Circle::Circle(const Point& c, double r) : center(c), rad(r), type(2){}

Circle::Circle(const Circle& other) : center(other.center), rad(other.rad){}

Circle::~Circle(){}

void Circle::save(std::string& name) {
	std::fstream out(name, std::ios::app);
	out << "3" << " " << center.x << " " << center.y << " " << rad <<std::endl;
}


void Circle::draw() const {
	std::cout << "�� - �߽���(" << center.x << "," << center.y << ") ������ " << rad << std::endl;
}
